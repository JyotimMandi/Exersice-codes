create database EmployeeManagementSystem;

use EmployeeManagementSystem;

-- Departments Table
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100)
);

-- Employees Table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DepartmentID INT FOREIGN KEY REFERENCES Departments(DepartmentID),
    Salary DECIMAL(10, 2),
    JoinDate DATE
);

-- Sample data
INSERT INTO Departments VALUES (1, 'HR'), (2, 'Engineering'), (3, 'Finance');

INSERT INTO Employees VALUES
(101, 'John', 'Doe', 2, 60000, '2022-01-15'),
(102, 'Jane', 'Smith', 1, 45000, '2021-09-01'),
(103, 'Alice', 'Brown', 3, 55000, '2023-03-12');

Select * from Departments;
Select * from Employees;

--Exercise 1
CREATE VIEW vw_EmployeeBasicInfo AS
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    d.DepartmentName
FROM Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID;

--Exercise 2
CREATE VIEW vw_EmployeeFullName AS
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    (e.FirstName + ' ' + e.LastName) AS FullName
FROM Employees e;

--Exercise 3
CREATE VIEW vw_EmployeeAnnualSalary AS
SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    (e.Salary * 12) AS AnnualSalary
FROM Employees e;

--Exercise 4
CREATE VIEW vw_EmployeeReport AS
SELECT 
    e.EmployeeID,
    (e.FirstName + ' ' + e.LastName) AS FullName,
    d.DepartmentName,
    (e.Salary * 12) AS AnnualSalary,
    (e.Salary * 12 * 0.10) AS Bonus
FROM Employees e
JOIN Departments d ON e.DepartmentID = d.DepartmentID;

