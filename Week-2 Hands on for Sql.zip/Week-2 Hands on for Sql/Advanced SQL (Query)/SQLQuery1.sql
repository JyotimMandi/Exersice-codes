create database OnlineRetailDB;

use OnlineRetailDB;


-- Database Schema
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(100),
    Region VARCHAR(50)
);

CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    Price DECIMAL(10, 2)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Sample Data
INSERT INTO Customers (CustomerID, Name, Region) VALUES
(1, 'Alice', 'North'),
(2, 'Bob', 'South'),
(3, 'Charlie', 'East'),
(4, 'David', 'West');

INSERT INTO Products (ProductID, ProductName, Category, Price) VALUES
(1, 'Laptop', 'Electronics', 1200.00),
(2, 'Smartphone', 'Electronics', 800.00),
(3, 'Tablet', 'Electronics', 600.00),
(4, 'Headphones', 'Accessories', 150.00);

INSERT INTO Orders (OrderID, CustomerID, OrderDate) VALUES
(1, 1, '2023-01-15'),
(2, 2, '2023-02-20'),
(3, 3, '2023-03-25'),
(4, 4, '2023-04-30');

INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 3, 1),
(4, 4, 4, 3);


--Exercise 1
-- ROW_NUMBER
SELECT 
    Category,
    ProductName,
    Price,
    ROW_NUMBER() OVER (PARTITION BY Category ORDER BY Price DESC) AS RowNum
FROM Products;

-- RANK
SELECT 
    Category,
    ProductName,
    Price,
    RANK() OVER (PARTITION BY Category ORDER BY Price DESC) AS RankNum
FROM Products;

-- DENSE_RANK
SELECT 
    Category,
    ProductName,
    Price,
    DENSE_RANK() OVER (PARTITION BY Category ORDER BY Price DESC) AS DenseRankNum
FROM Products;


--Exercise 2

-- GROUPING SETS
SELECT 
    c.Region, 
    p.Category,
    SUM(od.Quantity) AS TotalQty
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY GROUPING SETS (
    (c.Region),
    (p.Category),
    (c.Region, p.Category)
);

-- ROLLUP
SELECT 
    c.Region, 
    p.Category,
    SUM(od.Quantity) AS TotalQty
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY ROLLUP (c.Region, p.Category);

-- CUBE
SELECT 
    c.Region, 
    p.Category,
    SUM(od.Quantity) AS TotalQty
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY CUBE (c.Region, p.Category);

--Exercise 3

-- Recursive CTE for calendar
WITH Calendar AS (
    SELECT CAST('2025-01-01' AS DATE) AS DateValue
    UNION ALL
    SELECT DATEADD(DAY, 1, DateValue)
    FROM Calendar
    WHERE DateValue < '2025-01-31'
)
SELECT * FROM Calendar;

-- Staging table
CREATE TABLE StagingProducts (
    ProductID INT,
    Price DECIMAL(10,2)
);

INSERT INTO StagingProducts VALUES
(1, 1150.00), -- existing product (will update)
(7, 100.00);  -- new product (will insert)

-- MERGE
MERGE Products AS target
USING StagingProducts AS source
ON target.ProductID = source.ProductID
WHEN MATCHED THEN 
    UPDATE SET target.Price = source.Price
WHEN NOT MATCHED THEN 
    INSERT (ProductID, ProductName, Category, Price)
    VALUES (source.ProductID, 'New Product', 'Misc', source.Price);



--Exercise 4
-- Pivot: quantity by product & month
SELECT *
FROM (
    SELECT 
        p.ProductName,
        MONTH(o.OrderDate) AS SalesMonth,
        od.Quantity
    FROM Orders o
    JOIN OrderDetails od ON o.OrderID = od.OrderID
    JOIN Products p ON od.ProductID = p.ProductID
) src
PIVOT (
    SUM(Quantity) FOR SalesMonth IN ([1], [2], [3])
) AS pivot_table;


-- Unpivot the above
SELECT ProductName, SalesMonth, Quantity
FROM (
    SELECT ProductName, [1], [2], [3]
    FROM (
        SELECT 
            p.ProductName,
            MONTH(o.OrderDate) AS SalesMonth,
            od.Quantity
        FROM Orders o
        JOIN OrderDetails od ON o.OrderID = od.OrderID
        JOIN Products p ON od.ProductID = p.ProductID
    ) AS src
    PIVOT (
        SUM(Quantity) FOR SalesMonth IN ([1], [2], [3])
    ) AS pvt
) unpivot_src
UNPIVOT (
    Quantity FOR SalesMonth IN ([1], [2], [3])
) AS unpvt;

-- Add more orders for CustomerID = 1
INSERT INTO Orders (OrderID, CustomerID, OrderDate) VALUES
(5, 1, '2023-05-01'),
(6, 1, '2023-06-01'),
(7, 1, '2023-07-01');



--Exercise 5
-- Step 1: Create a CTE that counts the number of orders placed by each customer
WITH CustomerOrderCounts AS (
    SELECT 
        CustomerID,
        COUNT(OrderID) AS OrderCount
    FROM Orders
    GROUP BY CustomerID
)

-- Step 2: Select only those customers who have placed more than 3 orders
SELECT 
    c.CustomerID,
    c.Name,
    coc.OrderCount
FROM CustomerOrderCounts coc
JOIN Customers c ON coc.CustomerID = c.CustomerID
WHERE coc.OrderCount > 3;
