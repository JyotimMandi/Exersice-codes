create database EmployeeManagementSystem6;

use EmployeeManagementSystem6;

--Exercise 1
-- Step 1: Create EmployeeChanges table
CREATE TABLE EmployeeChanges (
    ChangeID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT,
    OldSalary DECIMAL(10,2),
    NewSalary DECIMAL(10,2),
    ChangeDate DATETIME DEFAULT GETDATE()
);

-- Step 2: Create AFTER UPDATE trigger on Employees to log salary changes
CREATE TRIGGER trg_AfterSalaryUpdate
ON Employees
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Insert a log record only if Salary has changed
    INSERT INTO EmployeeChanges (EmployeeID, OldSalary, NewSalary)
    SELECT
        i.EmployeeID,
        d.Salary AS OldSalary,
        i.Salary AS NewSalary
    FROM inserted i
    JOIN deleted d ON i.EmployeeID = d.EmployeeID
    WHERE i.Salary <> d.Salary;
END;


--Exercise 2
CREATE TRIGGER trg_PreventDelete
ON Employees
INSTEAD OF DELETE
AS
BEGIN
    RAISERROR('Deletion of employees is not allowed.', 16, 1);
    ROLLBACK TRANSACTION;
END;


--Exercise 3
CREATE TRIGGER trg_RestrictLogon
ON ALL SERVER
FOR LOGON
AS
BEGIN
    DECLARE @CurrentHour INT = DATEPART(HOUR, GETDATE());

    IF @CurrentHour >= 2 AND @CurrentHour < 3
    BEGIN
        ROLLBACK; -- Prevent login
        THROW 50000, 'Logins are not allowed during maintenance hours (2 AM - 3 AM).', 1;
    END
END;


--Exercise 4


--Exercise 5
DROP TRIGGER trg_AfterSalaryUpdate; -- Use the actual trigger name


--Exercise 6
-- Step 1: Add AnnualSalary column (not computed, because computed columns can't be updated via trigger)
ALTER TABLE Employees ADD AnnualSalary DECIMAL(12,2);

-- Step 2: Create trigger to update AnnualSalary whenever Salary changes
CREATE TRIGGER trg_UpdateAnnualSalary
ON Employees
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE e
    SET AnnualSalary = e.Salary * 12
    FROM Employees e
    JOIN inserted i ON e.EmployeeID = i.EmployeeID
    WHERE e.Salary = i.Salary;
END;
