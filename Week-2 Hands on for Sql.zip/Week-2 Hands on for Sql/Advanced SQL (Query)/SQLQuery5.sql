create database EmployeeManagementDB;

use EmployeeManagementDB;

-- Create Departments Table
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100)
);

-- Create Employees Table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DepartmentID INT FOREIGN KEY REFERENCES Departments(DepartmentID),
    Salary DECIMAL(10,2),
    JoinDate DATE
);

-- Insert Sample Data
INSERT INTO Departments (DepartmentID, DepartmentName) VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance');

INSERT INTO Employees (EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate) VALUES
(1, 'John', 'Doe', 1, 5000.00, '2020-01-15'),
(2, 'Jane', 'Smith', 2, 6000.00, '2019-03-22'),
(3, 'Bob', 'Johnson', 3, 5500.00, '2021-07-01');


--Exercise 1
CREATE FUNCTION fn_CalculateAnnualSalary (@MonthlySalary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @AnnualSalary DECIMAL(10,2);
    SET @AnnualSalary = @MonthlySalary * 12;
    RETURN @AnnualSalary;
END;
GO

SELECT 
    EmployeeID,
    FirstName,
    LastName,
    dbo.fn_CalculateAnnualSalary(Salary) AS AnnualSalary
FROM Employees;



--Exercise 2
CREATE FUNCTION fn_GetEmployeesByDepartment (@DeptID INT)
RETURNS TABLE
AS
RETURN (
    SELECT EmployeeID, FirstName, LastName, Salary, JoinDate
    FROM Employees
    WHERE DepartmentID = @DeptID
);
GO 

SELECT * FROM dbo.fn_GetEmployeesByDepartment(2);



--Exercise 3
CREATE FUNCTION fn_CalculateBonus (@Salary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Bonus DECIMAL(10,2);
    SET @Bonus = @Salary * 0.10;
    RETURN @Bonus;
END;
GO  -- End batch

-- Use the function
SELECT 
    EmployeeID,
    FirstName,
    LastName,
    dbo.fn_CalculateBonus(Salary) AS Bonus
FROM Employees;



--Exercise 4
ALTER FUNCTION fn_CalculateBonus (@Salary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Bonus DECIMAL(10,2);
    SET @Bonus = @Salary * 0.15;
    RETURN @Bonus;
END;
GO  

SELECT 
    EmployeeID,
    FirstName,
    LastName,
    dbo.fn_CalculateBonus(Salary) AS Bonus
FROM Employees;




--Exercise 5
DROP FUNCTION fn_CalculateBonus;

SELECT dbo.fn_CalculateBonus(5000);



--Exercise 6
SELECT 
    EmployeeID,
    FirstName,
    LastName,
    dbo.fn_CalculateAnnualSalary(Salary) AS AnnualSalary
FROM Employees;


--Exercise 7
SELECT dbo.fn_CalculateAnnualSalary(
    (SELECT Salary FROM Employees WHERE EmployeeID = 1)
) AS AnnualSalary;


--Exercise 8
SELECT * FROM dbo.fn_GetEmployeesByDepartment(3);


--Exercise 9
CREATE FUNCTION fn_CalculateBonus (@Salary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @Bonus DECIMAL(10,2);
    SET @Bonus = @Salary * 0.15;
    RETURN @Bonus;
END;
GO  

CREATE FUNCTION fn_CalculateTotalCompensation (@Salary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @AnnualSalary DECIMAL(10,2) = dbo.fn_CalculateAnnualSalary(@Salary);
    DECLARE @Bonus DECIMAL(10,2) = dbo.fn_CalculateBonus(@Salary);
    RETURN @AnnualSalary + @Bonus;
END;
GO


SELECT 
    EmployeeID,
    FirstName,
    LastName,
    dbo.fn_CalculateTotalCompensation(Salary) AS TotalCompensation
FROM Employees;



--Exercise 10
ALTER FUNCTION fn_CalculateTotalCompensation (@Salary DECIMAL(10,2))
RETURNS DECIMAL(10,2)
AS
BEGIN
    DECLARE @AnnualSalary DECIMAL(10,2) = dbo.fn_CalculateAnnualSalary(@Salary);
    DECLARE @Bonus DECIMAL(10,2) = dbo.fn_CalculateBonus(@Salary);  -- now returns 20%
    RETURN @AnnualSalary + @Bonus;
END;
GO

SELECT 
    EmployeeID,
    FirstName,
    LastName,
    Salary,
    dbo.fn_CalculateTotalCompensation(Salary) AS TotalCompensation
FROM Employees;
