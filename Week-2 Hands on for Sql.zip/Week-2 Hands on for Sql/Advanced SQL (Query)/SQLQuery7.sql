create database EmployeeManagementSystem7;

use EmployeeManagementSystem7;

CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100)
);

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DepartmentID INT FOREIGN KEY REFERENCES Departments(DepartmentID),
    Salary DECIMAL(10,2),
    JoinDate DATE
);

INSERT INTO Departments (DepartmentID, DepartmentName) VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance');

INSERT INTO Employees (EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate) VALUES
(1, 'John', 'Doe', 1, 5000.00, '2020-01-15'),
(2, 'Jane', 'Smith', 2, 6000.00, '2019-03-22'),
(3, 'Bob', 'Johnson', 3, 5500.00, '2021-07-30');



--Exercise 1
DECLARE @EmployeeID INT,
        @FirstName VARCHAR(50),
        @LastName VARCHAR(50),
        @DepartmentID INT,
        @Salary DECIMAL(10,2),
        @JoinDate DATE;

DECLARE EmployeeCursor CURSOR FOR
    SELECT EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate
    FROM Employees;

OPEN EmployeeCursor;

FETCH NEXT FROM EmployeeCursor INTO @EmployeeID, @FirstName, @LastName, @DepartmentID, @Salary, @JoinDate;

WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT CONCAT('ID: ', @EmployeeID, ', Name: ', @FirstName, ' ', @LastName,
                 ', DeptID: ', @DepartmentID, ', Salary: ', @Salary, ', JoinDate: ', CONVERT(VARCHAR, @JoinDate, 23));

    FETCH NEXT FROM EmployeeCursor INTO @EmployeeID, @FirstName, @LastName, @DepartmentID, @Salary, @JoinDate;
END;

CLOSE EmployeeCursor;
DEALLOCATE EmployeeCursor;


--Exercise 2
-- 1. Static Cursor
DECLARE StaticCursor CURSOR STATIC FOR
    SELECT EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate FROM Employees;

-- 2. Dynamic Cursor
DECLARE DynamicCursor CURSOR DYNAMIC FOR
    SELECT EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate FROM Employees;

-- 3. Forward-Only Cursor
DECLARE ForwardOnlyCursor CURSOR FAST_FORWARD FOR
    SELECT EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate FROM Employees;

-- 4. Keyset-Driven Cursor
DECLARE KeysetCursor CURSOR KEYSET FOR
    SELECT EmployeeID, FirstName, LastName, DepartmentID, Salary, JoinDate FROM Employees;
