﻿public interface Notifier
{
    void Send(string message);
}
