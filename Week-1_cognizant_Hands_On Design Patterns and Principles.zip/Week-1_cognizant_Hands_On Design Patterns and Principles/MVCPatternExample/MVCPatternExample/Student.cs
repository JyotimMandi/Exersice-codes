﻿public class Student
{
    public string Name { get; set; }
    public string Id { get; set; }
    public string Grade { get; set; }
}
