﻿using System;

class Program
{
    static void Main(string[] args)
    {
        ICustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        service.GetCustomerInfo(1); 
        service.GetCustomerInfo(3); 
    }
}
