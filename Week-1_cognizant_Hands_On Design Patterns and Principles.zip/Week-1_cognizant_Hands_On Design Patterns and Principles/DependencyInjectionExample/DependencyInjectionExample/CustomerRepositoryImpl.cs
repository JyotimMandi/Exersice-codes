﻿
using System;
using System.Collections.Generic;

public class CustomerRepositoryImpl : ICustomerRepository
{
    private Dictionary<int, Customer> _customers = new Dictionary<int, Customer>
    {
        { 1, new Customer { Id = 1, Name = "Alice" } },
        { 2, new Customer { Id = 2, Name = "Bob" } }
    };

    public Customer FindCustomerById(int id)
    {
        return _customers.ContainsKey(id) ? _customers[id] : null;
    }
}
