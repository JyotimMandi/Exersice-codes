﻿using System;

public class PayPalGateway
{
    public void MakePayment(double amount)
    {
        Console.WriteLine($"PayPal: Processing payment of ${amount}");
    }
}
