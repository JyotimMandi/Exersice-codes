﻿public interface PaymentProcessor
{
    void ProcessPayment(double amount);
}
