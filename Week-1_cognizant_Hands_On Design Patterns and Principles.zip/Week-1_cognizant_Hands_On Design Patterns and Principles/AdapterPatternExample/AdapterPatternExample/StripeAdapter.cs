﻿public class StripeAdapter : PaymentProcessor
{
    private StripeGateway _stripe = new StripeGateway();

    public void ProcessPayment(double amount)
    {
        _stripe.SendPayment(amount);
    }
}
