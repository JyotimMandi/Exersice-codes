﻿using System;

class Program
{
    static void Main(string[] args)
    {
        PaymentProcessor paypalProcessor = new PayPalAdapter();
        paypalProcessor.ProcessPayment(250.00);

        PaymentProcessor stripeProcessor = new StripeAdapter();
        stripeProcessor.ProcessPayment(150.00);
    }
}
