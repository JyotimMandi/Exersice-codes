﻿using System;

class Program
{
    static void Main(string[] args)
    {
        PaymentContext context = new PaymentContext();

        // Use Credit Card
        context.SetPaymentStrategy(new CreditCardPayment());
        context.ExecutePayment(1500.00);

        // Use PayPal
        context.SetPaymentStrategy(new PayPalPayment());
        context.ExecutePayment(2500.00);
    }
}
