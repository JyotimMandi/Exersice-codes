﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Book[] books = {
            new Book(1, "C Programming", "Dennis Ritchie"),
            new Book(2, "Clean Code", "Robert Martin"),
            new Book(3, "Algorithms", "Cormen"),
            new Book(4, "Design Patterns", "Gamma"),
            new Book(5, "Data Structures", "Mark Allen Weiss")
        };

        Console.WriteLine("🔎 Linear Search for 'Clean Code':");
        Book? result1 = Library.LinearSearch(books, "Clean Code");
        Console.WriteLine(result1 != null ? result1.ToString() : "Book not found.");

        Console.WriteLine("\n🔃 Sorting books for Binary Search...");
        Library.SortBooksByTitle(books);

        Console.WriteLine("\n🔎 Binary Search for 'Clean Code':");
        Book? result2 = Library.BinarySearch(books, "Clean Code");
        Console.WriteLine(result2 != null ? result2.ToString() : "Book not found.");
    }
}
