﻿class Program
{
    static void Main(string[] args)
    {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Shirt", "Apparel"),
            new Product(3, "Phone", "Electronics"),
            new Product(4, "Shoes", "Footwear"),
            new Product(5, "Watch", "Accessories")
        };

        Console.WriteLine("Linear Search:");
        Product result1 = SearchEngine.LinearSearch(products, "Phone");
        Console.WriteLine(result1 != null ? result1.ToString() : "Product not found");

        Console.WriteLine("\nBinary Search:");
        SearchEngine.SortProducts(products);
        Product result2 = SearchEngine.BinarySearch(products, "Phone");
        Console.WriteLine(result2 != null ? result2.ToString() : "Product not found");
    }
}
