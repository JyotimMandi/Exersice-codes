﻿using System;

public class SearchEngine
{
    public static Product LinearSearch(Product[] products, string name)
    {
        foreach (var product in products)
        {
            if (product.ProductName.Equals(name, StringComparison.OrdinalIgnoreCase))
                return product;
        }
        return null;
    }

    public static Product BinarySearch(Product[] products, string name)
    {
        int low = 0, high = products.Length - 1;

        while (low <= high)
        {
            int mid = (low + high) / 2;
            int comparison = string.Compare(products[mid].ProductName, name, true);

            if (comparison == 0)
                return products[mid];
            else if (comparison < 0)
                low = mid + 1;
            else
                high = mid - 1;
        }

        return null;
    }

    public static void SortProducts(Product[] products)
    {
        Array.Sort(products, (p1, p2) => string.Compare(p1.ProductName, p2.ProductName, true));
    }
}
