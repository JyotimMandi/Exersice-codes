﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double presentValue = 10000;     
        double growthRate = 0.05;        
        int years = 5;                   

        Console.WriteLine("Financial Forecasting using Recursion");
        double futureValue = Forecaster.PredictFutureValue(presentValue, growthRate, years);
        Console.WriteLine($"Future value (recursive): {futureValue:F2}");

        double futureValueIterative = Forecaster.PredictFutureValueIterative(presentValue, growthRate, years);
        Console.WriteLine($"Future value (iterative): {futureValueIterative:F2}");
    }
}
