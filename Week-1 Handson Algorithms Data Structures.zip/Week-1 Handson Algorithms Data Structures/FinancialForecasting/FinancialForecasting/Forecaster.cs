﻿using System;

public class Forecaster
{
    
    public static double PredictFutureValue(double presentValue, double growthRate, int years)
    {
        if (years == 0)
            return presentValue;

        return PredictFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }

    
    public static double PredictFutureValueIterative(double presentValue, double growthRate, int years)
    {
        double result = presentValue;
        for (int i = 0; i < years; i++)
        {
            result *= (1 + growthRate);
        }
        return result;
    }
}
