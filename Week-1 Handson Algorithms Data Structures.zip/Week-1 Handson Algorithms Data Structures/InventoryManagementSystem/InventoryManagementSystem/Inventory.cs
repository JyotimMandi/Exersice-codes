﻿using System;
using System.Collections.Generic;

public class Inventory
{
    private Dictionary<int, Product> products = new Dictionary<int, Product>();

    public void AddProduct(Product product)
    {
        if (products.ContainsKey(product.ProductId))
        {
            Console.WriteLine("Product with same ID already exists.");
            return;
        }
        products[product.ProductId] = product;
        Console.WriteLine("Product added.");
    }

    public void UpdateProduct(int productId, int quantity, double price)
    {
        if (products.ContainsKey(productId))
        {
            products[productId].Quantity = quantity;
            products[productId].Price = price;
            Console.WriteLine("Product updated.");
        }
        else
        {
            Console.WriteLine("Product not found.");
        }
    }

    public void DeleteProduct(int productId)
    {
        if (products.Remove(productId))
            Console.WriteLine("Product deleted.");
        else
            Console.WriteLine("Product not found.");
    }

    public void DisplayAll()
    {
        Console.WriteLine("\nAll Products:");
        foreach (var product in products.Values)
        {
            Console.WriteLine(product);
        }
    }
}
