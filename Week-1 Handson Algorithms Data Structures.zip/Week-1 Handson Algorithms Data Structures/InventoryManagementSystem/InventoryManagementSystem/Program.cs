﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Inventory inventory = new Inventory();

        
        inventory.AddProduct(new Product(101, "Mouse", 50, 499.99));
        inventory.AddProduct(new Product(102, "Keyboard", 30, 899.50));

       
        inventory.UpdateProduct(101, 45, 459.99);

       
        inventory.DeleteProduct(102);

        
        inventory.DisplayAll();
    }
}
