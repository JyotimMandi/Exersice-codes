﻿using System;

class Program
{
    static void Main(string[] args)
    {
        TaskList taskList = new TaskList();

        taskList.AddTask(new Task(1, "Design UI", "Pending"));
        taskList.AddTask(new Task(2, "Develop API", "In Progress"));
        taskList.AddTask(new Task(3, "Test Functionality", "Pending"));

        Console.WriteLine("\nAll Tasks:");
        taskList.Traverse();

        Console.WriteLine("\nSearching for Task ID 2:");
        Task? task = taskList.SearchTask(2);
        Console.WriteLine(task != null ? task.ToString() : "Task not found.");

        Console.WriteLine("\nDeleting Task ID 1:");
        taskList.DeleteTask(1);

        Console.WriteLine("\nAll Tasks After Deletion:");
        taskList.Traverse();
    }
}
