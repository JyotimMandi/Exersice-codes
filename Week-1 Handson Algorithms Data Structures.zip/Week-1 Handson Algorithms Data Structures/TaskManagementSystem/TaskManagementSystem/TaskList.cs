﻿using System;

public class TaskList
{
    private TaskNode? head = null;

    public void AddTask(Task task)
    {
        TaskNode newNode = new TaskNode(task);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            TaskNode current = head;
            while (current.Next != null)
                current = current.Next;
            current.Next = newNode;
        }
        Console.WriteLine("Task added.");
    }

    public Task? SearchTask(int taskId)
    {
        TaskNode? current = head;
        while (current != null)
        {
            if (current.Data.TaskId == taskId)
                return current.Data;
            current = current.Next;
        }
        return null;
    }

    public void DeleteTask(int taskId)
    {
        if (head == null)
        {
            Console.WriteLine("No tasks to delete.");
            return;
        }

        if (head.Data.TaskId == taskId)
        {
            head = head.Next;
            Console.WriteLine("Task deleted.");
            return;
        }

        TaskNode? current = head;
        while (current.Next != null && current.Next.Data.TaskId != taskId)
        {
            current = current.Next;
        }

        if (current.Next != null)
        {
            current.Next = current.Next.Next;
            Console.WriteLine("Task deleted.");
        }
        else
        {
            Console.WriteLine("Task not found.");
        }
    }

    public void Traverse()
    {
        TaskNode? current = head;
        while (current != null)
        {
            Console.WriteLine(current.Data);
            current = current.Next;
        }
    }
}
