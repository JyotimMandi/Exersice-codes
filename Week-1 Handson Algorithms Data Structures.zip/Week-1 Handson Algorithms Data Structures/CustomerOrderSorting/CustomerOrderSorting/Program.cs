﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Order[] orders = {
            new Order(101, "Alice", 1599.99),
            new Order(102, "Bob", 499.00),
            new Order(103, "Charlie", 2500.75),
            new Order(104, "Diana", 1200.50),
        };

        Console.WriteLine("Original Orders:");
        foreach (var o in orders) Console.WriteLine(o);

    
        Console.WriteLine("\nBubble Sort:");
        Sorter.BubbleSort(orders);
        foreach (var o in orders) Console.WriteLine(o);

        
        orders = new Order[] {
            new Order(101, "Alice", 1599.99),
            new Order(102, "Bob", 499.00),
            new Order(103, "Charlie", 2500.75),
            new Order(104, "Diana", 1200.50),
        };

        Console.WriteLine("\nQuick Sort:");
        Sorter.QuickSort(orders, 0, orders.Length - 1);
        foreach (var o in orders) Console.WriteLine(o);
    }
}
