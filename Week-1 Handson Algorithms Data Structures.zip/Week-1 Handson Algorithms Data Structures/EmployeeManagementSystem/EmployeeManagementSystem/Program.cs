﻿using System;

class Program
{
    static void Main(string[] args)
    {
        EmployeeManager manager = new EmployeeManager(5);

        manager.AddEmployee(new Employee(1, "Alice", "Manager", 60000));
        manager.AddEmployee(new Employee(2, "Bob", "Developer", 50000));
        manager.AddEmployee(new Employee(3, "Charlie", "Designer", 45000));

        Console.WriteLine("\nAll Employees:");
        manager.DisplayAll();

        Console.WriteLine("\nSearching for Employee with ID 2:");
        Employee? emp = manager.SearchEmployee(2);
        Console.WriteLine(emp != null ? emp.ToString() : "Not found");

        Console.WriteLine("\nDeleting Employee with ID 1:");
        manager.DeleteEmployee(1);

        Console.WriteLine("\nAll Employees After Deletion:");
        manager.DisplayAll();
    }
}
