﻿using System;

public class EmployeeManager
{
    private Employee[] employees;
    private int count = 0;

    public EmployeeManager(int capacity)
    {
        employees = new Employee[capacity];
    }

    public void AddEmployee(Employee emp)
    {
        if (count < employees.Length)
        {
            employees[count++] = emp;
            Console.WriteLine("Employee added.");
        }
        else
        {
            Console.WriteLine("Array is full. Cannot add more employees.");
        }
    }

    public Employee SearchEmployee(int id)
    {
        for (int i = 0; i < count; i++)
        {
            if (employees[i].EmployeeId == id)
                return employees[i];
        }
        return null;
    }

    public void DisplayAll()
    {
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine(employees[i]);
        }
    }

    public void DeleteEmployee(int id)
    {
        for (int i = 0; i < count; i++)
        {
            if (employees[i].EmployeeId == id)
            {
                for (int j = i; j < count - 1; j++)
                {
                    employees[j] = employees[j + 1];
                }
                employees[--count] = null;
                Console.WriteLine("Employee deleted.");
                return;
            }
        }
        Console.WriteLine("Employee not found.");
    }
}
