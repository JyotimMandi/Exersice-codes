﻿

public interface ICustomerRepository
{
    Customer FindCustomerById(int id);
}
