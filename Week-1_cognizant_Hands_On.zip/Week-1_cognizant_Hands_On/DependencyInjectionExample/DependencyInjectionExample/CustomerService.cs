﻿using System;

public class CustomerService
{
    private readonly ICustomerRepository _repository;

  
    public CustomerService(ICustomerRepository repository)
    {
        _repository = repository;
    }

    public void GetCustomerInfo(int id)
    {
        var customer = _repository.FindCustomerById(id);
        if (customer != null)
        {
            Console.WriteLine($"Customer Found: ID = {customer.Id}, Name = {customer.Name}");
        }
        else
        {
            Console.WriteLine("Customer not found.");
        }
    }
}
