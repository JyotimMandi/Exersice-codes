﻿public class PaymentContext
{
    private IPaymentStrategy _paymentStrategy;

    public void SetPaymentStrategy(IPaymentStrategy strategy)
    {
        _paymentStrategy = strategy;
    }

    public void ExecutePayment(double amount)
    {
        _paymentStrategy.Pay(amount);
    }
}
