﻿public class StudentController
{
    private Student _student;
    private StudentView _view;

    public StudentController(Student student, StudentView view)
    {
        _student = student;
        _view = view;
    }

    public void SetStudentName(string name) => _student.Name = name;
    public void SetStudentId(string id) => _student.Id = id;
    public void SetStudentGrade(string grade) => _student.Grade = grade;

    public string GetStudentName() => _student.Name;
    public string GetStudentId() => _student.Id;
    public string GetStudentGrade() => _student.Grade;

    public void UpdateView()
    {
        _view.DisplayStudentDetails(_student.Name, _student.Id, _student.Grade);
    }
}
