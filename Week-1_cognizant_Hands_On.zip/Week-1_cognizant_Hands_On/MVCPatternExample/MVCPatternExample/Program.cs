﻿using System;

class Program
{
    static void Main(string[] args)
    {
       
        Student student = new Student();
        StudentView view = new StudentView();

        
        StudentController controller = new StudentController(student, view);

     
        controller.SetStudentName("Jyotim Mandi");
        controller.SetStudentId("S12345");
        controller.SetStudentGrade("A");

        
        controller.UpdateView();

  
        controller.SetStudentGrade("A+");
        Console.WriteLine("\nAfter Grade Update:");
        controller.UpdateView();
    }
}
