﻿public class PayPalAdapter : PaymentProcessor
{
    private PayPalGateway _paypal = new PayPalGateway();

    public void ProcessPayment(double amount)
    {
        _paypal.MakePayment(amount);
    }
}
