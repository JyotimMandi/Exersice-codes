﻿using System;

public class StripeGateway
{
    public void SendPayment(double amount)
    {
        Console.WriteLine($"Stripe: Sending payment of ${amount}");
    }
}
