﻿using System;

class Program
{
    static void Main(string[] args)
    {
       
        Computer gamingPC = new Computer.Builder()
            .SetCPU("Intel Core i9")
            .SetRAM("32GB")
            .SetStorage("1TB SSD")
            .SetGPU("NVIDIA RTX 4090")
            .Build();

        gamingPC.DisplayConfig();
        Console.WriteLine();

        
        Computer officePC = new Computer.Builder()
            .SetCPU("Intel Core i5")
            .SetRAM("16GB")
            .SetStorage("512GB SSD")
            .Build();

        officePC.DisplayConfig();
    }
}
