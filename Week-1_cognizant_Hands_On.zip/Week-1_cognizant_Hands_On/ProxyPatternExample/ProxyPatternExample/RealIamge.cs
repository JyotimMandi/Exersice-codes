﻿using System;

public class RealImage : Image
{
    private string _fileName;

    public RealImage(string fileName)
    {
        _fileName = fileName;
        LoadFromRemoteServer();
    }

    private void LoadFromRemoteServer()
    {
        Console.WriteLine($"Loading {_fileName} from remote server...");
    }

    public void Display()
    {
        Console.WriteLine($"Displaying {_fileName}");
    }
}
