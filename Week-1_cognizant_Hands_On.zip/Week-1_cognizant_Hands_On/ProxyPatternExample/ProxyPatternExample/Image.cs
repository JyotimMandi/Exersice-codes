﻿public interface Image
{
    void Display();
}
