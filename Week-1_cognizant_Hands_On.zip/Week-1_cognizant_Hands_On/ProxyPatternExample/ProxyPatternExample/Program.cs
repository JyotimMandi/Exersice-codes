﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Image image1 = new ProxyImage("photo1.jpg");
        Image image2 = new ProxyImage("photo2.jpg");

        Console.WriteLine("First call:");
        image1.Display();  

        Console.WriteLine("\nSecond call:");
        image1.Display();  

        Console.WriteLine("\nNew image:");
        image2.Display(); 
    }
}
