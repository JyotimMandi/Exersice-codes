﻿using System;

class Program
{
    static void Main(string[] args)
    {
        StockMarket stockMarket = new StockMarket("AAPL");

        IObserver mobileApp = new MobileApp();
        IObserver webApp = new WebApp();

        stockMarket.Register(mobileApp);
        stockMarket.Register(webApp);

        stockMarket.SetPrice(145.20);
        Console.WriteLine();

        stockMarket.SetPrice(147.85);
        Console.WriteLine();

        stockMarket.Deregister(webApp);
        stockMarket.SetPrice(150.00);
    }
}
