﻿using System;
using System.Collections.Generic;

public class StockMarket : IStock
{
    private readonly List<IObserver> _observers = new List<IObserver>();
    private string _stockName;
    private double _price;

    public StockMarket(string stockName)
    {
        _stockName = stockName;
    }

    public void Register(IObserver observer)
    {
        _observers.Add(observer);
    }

    public void Deregister(IObserver observer)
    {
        _observers.Remove(observer);
    }

    public void NotifyObservers()
    {
        foreach (var observer in _observers)
        {
            observer.Update(_stockName, _price);
        }
    }

    public void SetPrice(double price)
    {
        _price = price;
        NotifyObservers();
    }
}
